<?php

$_['heading_title'] = 'ReelPay';

$_['text_extension'] = 'Extensions';
$_['text_success'] = 'ReelPay payment details have been successfully updated.';
$_['error_reelpay_wrong_key'] = 'Wrong key!';
$_['error_reelpay_appkey'] = 'APP KEY cannot be empty !';
$_['error_reelpay_appid'] = 'APP ID cannot be empty !';

$_['entry_status'] = 'Status';
$_['entry_appid'] = 'APP ID';
$_['entry_appkey'] = 'APP KEY';
$_['entry_sort_order'] = 'Sort Order';
$_['entry_order_status'] = 'Order Status';
$_['entry_order_paid_status'] = 'Order Success Status';
$_['entry_time_out_status'] = 'Order Timeout Status';
$_['entry_fail_status'] = 'Order Fail Status';

$_['text_reelpay'] = '<a href="https://reelpay.com/" target="_blank" rel="noopener"><img src="https://reel-block-n.s3.ap-east-1.amazonaws.com/base/202308/412dea63e624f909.jpg" alt="Reelpay" title="Reelpay" /></a>';
