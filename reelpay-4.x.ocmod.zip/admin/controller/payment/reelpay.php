<?php
namespace Opencart\Admin\Controller\Extension\Reelpay\Payment;


use Opencart\System\Library\Extension\Reelpay\Reelpayclient;
use Opencart\System\Engine\Controller;

class Reelpay extends Controller
{
    private $error = array();

    public function index(): void
    {
		$this->load->language('extension/reelpay/payment/reelpay');
		$this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		$data['save'] = $this->url->link('extension/reelpay/payment/reelpay.save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

		$data['breadcrumbs'] = [];
		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/reelpay/payment/reelpay', 'user_token=' . $this->session->data['user_token'])
		];

        $fields = array(
            'payment_reelpay_status',
            'payment_reelpay_appid',
            'payment_reelpay_appkey',
            'payment_reelpay_sort_order',
            'payment_reelpay_order_status_id',
            'payment_reelpay_paid_status_id',
            'payment_reelpay_time_out_status_id',
            'payment_reelpay_fail_status_id',
            );
		foreach ($fields as $field) {
			$data[$field] = $this->config->get($field);
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/reelpay/payment/reelpay', $data));
    }

	public function save(): void
	{
		$this->response->addHeader('Content-Type: application/json');
		$this->load->language('extension/reelpay/payment/reelpay');
		if (!$this->user->hasPermission('modify', 'extension/reelpay/payment/reelpay')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if (count($this->error) > 0) {
			$data['error'] = $this->error;
			$this->response->setOutput(json_encode($data));
			return;
		}
		$this->validate();
		if (count($this->error) > 0) {
			$data['error'] = $this->error;
			$this->response->setOutput(json_encode($data));
			return;
		}
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('payment_reelpay', $this->request->post);
		$data['success'] = $this->language->get('text_success');
		$this->response->setOutput(json_encode($data));
	}

    protected function validate()
    {
		$this->load->language('extension/reelpay/payment/reelpay');
        if (!isset($this->request->post['payment_reelpay_appkey'])) {
            $this->error['warning'] = $this->language->get('error_reelpay_appkey');
        }
        if (!isset($this->request->post['payment_reelpay_appid'])) {
            $this->error['warning'] = $this->language->get('error_reelpay_appid');
        }
        $reelpay = new Reelpayclient($this->request->post['payment_reelpay_appkey'], $this->request->post['payment_reelpay_appid']);
        $res = $reelpay->Currency([]);
        if (empty($res) || !isset($res["code"]) || $res["code"] != 200) {
            $this->error['warning'] = $this->language->get('error_reelpay_wrong_key');
        }
        return !$this->error;
    }

    public function install()
    {
        $this->load->model('extension/reelpay/payment/reelpay');

        $this->model_extension_reelpay_payment_reelpay->install();
    }

    public function uninstall(){}
}
