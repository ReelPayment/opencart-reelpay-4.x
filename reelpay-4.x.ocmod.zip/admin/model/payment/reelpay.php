<?php
namespace Opencart\Admin\Model\Extension\Reelpay\Payment;

use Opencart\System\Engine\Model;
class Reelpay extends Model
{
    public function install()
    {
        $this->load->model('setting/setting');

        $defaults = array();
        $defaults['payment_reelpay_appid'] = '';
        $defaults['payment_reelpay_appkey'] = false;
        $defaults['payment_reelpay_sort_order'] = 1;
        $defaults['payment_reelpay_order_status_id'] = 5;
        $defaults['payment_reelpay_paid_status_id'] = 5;
        $defaults['payment_reelpay_time_out_status_id'] = 14;
        $defaults['payment_reelpay_fail_status_id'] = 10;

        $this->model_setting_setting->editSetting('payment_reelpay', $defaults);
    }
}
