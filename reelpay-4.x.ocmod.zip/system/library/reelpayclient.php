<?php
namespace Opencart\System\Library\Extension\Reelpay;

class Reelpayclient
{
    protected $baseUrl = 'https://api.reelpay.com';
    protected $appID;
    protected $appKey;

    function __construct($appKey, $appID)
    {
        $this->appID = $appID;
        $this->appKey = $appKey;
    }

    public function EntrustPay(array $req)
    {
        return $this->request('/v1/transactions/entrust', $req);
    }

    public function Currency(array $req)
    {
        return $this->request('/v1/transactions/currency', $req);
    }

    /**
     * @param $url
     * @param array $data
     * @param int $second
     * @return bool|string
     */
    protected function request($url, $data, $second = 30)
    {
        $cover = new reelpaycover($this->appKey, $data);
        $cover->HmacSHA256Sign();
        $header = array(
            'content-type:application/json',
            "X-Timestamp:{$cover->timestamp}",
            "X-Appid:{$this->appID}",
            "X-Sign:{$cover->sign}"
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_TIMEOUT, $second);
        curl_setopt($ch, CURLOPT_URL, $this->baseUrl.$url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $this->baseUrl.$url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $cover->body);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        $res = curl_exec($ch);
        curl_close($ch);
        return $this->jsonDecode($res);
    }

    private function jsonDecode($data)
    {
        if (PHP_INT_SIZE < 8 && version_compare(PHP_VERSION, '5.4.0') >= 0) {
            // We are on 32-bit PHP, so use the bigint as string option. If you are using any API calls with Satoshis it is highly NOT recommended to use 32-bit PHP
            $dec = json_decode($data, TRUE, 512, JSON_BIGINT_AS_STRING);
        } else {
            $dec = json_decode($data, TRUE);
        }
        return $dec;
    }
}
