<?php

namespace Opencart\Catalog\Model\Extension\Reelpay\Payment;

use Opencart\System\Engine\Model;

class Reelpay extends Model
{

    public function getMethods($address)
    {
        $this->load->language('extension/reelpay/payment/reelpay');

        $option_data['reelpay'] = [
            'code' => 'reelpay.reelpay',
            'name' => $this->language->get('text_title')
        ];

        return [
            'code' => 'reelpay',
            'name' => $this->language->get('text_title'),
            'option' => $option_data,
            'sort_order' => $this->config->get('payment_plisio_sort_order')
        ];
    }
}
