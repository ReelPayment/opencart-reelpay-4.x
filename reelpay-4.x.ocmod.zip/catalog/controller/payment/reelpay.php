<?php

namespace Opencart\Catalog\Controller\Extension\Reelpay\Payment;

use Opencart\System\Engine\Controller;
use Opencart\System\Library\Extension\Reelpay\Reelpayclient;
use Opencart\System\Library\Extension\Reelpay\Reelpaycover;

class Reelpay extends Controller
{

    public function index()
    {
		$this->load->language('extension/reelpay/payment/reelpay');
		$this->load->model('checkout/order');

        $data['button_confirm'] = $this->language->get('button_confirm');
        if (!isset($this->session->data['order_id'])) {
            return false;
        }
        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        $this->load->model('tool/image');
        $amount = $order_info['total'] * $this->currency->getvalue($order_info['currency_code']);
        $reelpay = new reelpayclient($this->config->get('payment_reelpay_appkey'), $this->config->get('payment_reelpay_appid'));
        $image = $this->model_tool_image->resize($this->config->get('config_image'), 100, 100);
        $description = [];
        foreach ($this->cart->getProducts() as $product) {
            $description[] = $product['quantity'] . ' × ' . $product['name'];
        }
        $req = array(
            'out_trade_no'=> trim($order_info['order_id']),
            'symbol' => $order_info['currency_code'],
            'amount' => strval($amount),
            'name' => trim($this->config->get('config_name')),
            'image' => $image == null ? '' : $image,
            'describe' => implode(',', $description),
        );
        $res = $reelpay->EntrustPay($req);
        $data = [];
        if (empty($res) || $res["code"] != 200) {
            $data['fail'] = false;
        }else{
            $data['action'] = $res["data"]["url"];
        }
        return $this->load->view('extension/reelpay/payment/reelpay', $data);
    }

    public function callback()
    {
        $this->log->write('reelpay pay notify:');
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        $server = $_SERVER;
        if ($data['appid'] !== $this->config->get('payment_reelpay_appid')) {
            $this->log->write('reelpay APP ID check failed');
            $this->response->addHeader('HTTP/1.1 400 Bad Request');
            echo "fail";
            return;
        }
        if ($server['HTTP_X_TIMESTAMP'] > time() || $server['HTTP_X_TIMESTAMP'] < time() - 10) {
            $this->log->write('reelpay time check failed');
            $this->response->addHeader('HTTP/1.1 400 Bad Request');
            echo "fail";
            return;
        }
        $reelpayCover =  new reelpaycover($this->config->get('payment_reelpay_appkey'), $data);
        $reelpayCover->timestamp = $server['HTTP_X_TIMESTAMP'];
        if (!$reelpayCover->ValidateSign($server['HTTP_X_SIGN'])) {
            $this->log->write('reelpay Sign check failed');
            $this->response->addHeader('HTTP/1.1 400 Bad Request');
            echo "fail";
            return;
        }

        $this->load->model('checkout/order');
        $order_id = $data['out_trade_no'];
        switch ($server['HTTP_X_EVENTTYPE']) {
            case 'PAID':
                $order_status = 'payment_reelpay_paid_status_id';
                break;
            case 'TIME-OUT':
                $order_status = 'payment_reelpay_time_out_status_id';
                break;
            default:
                $order_status = 'payment_reelpay_fail_status_id';
        }
        $this->model_checkout_order->addOrderHistory($order_id, $this->config->get($order_status), $data['trade_no'], true);
        $this->log->write('reelpay status check successed');
        $this->response->addHeader('HTTP/1.1 200 OK');
        echo "success";
    }
}
